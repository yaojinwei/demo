package com.le.jr.test;

/**
 * @author Yao.Jinwei
 * @date 2017/3/22 18:32
 * @Copyright(c) Beijing LeFinance Software Co.,LTD
 */
public class HelloWorld {
    public void print(){
        System.out.println("hello world!");
    }
}
